import React from 'react';

function HealthStats() {
    return (
        <div>
            <div style={{ padding: '20px' }}>
                <h2>Health Statistics</h2>
                <p>This is the health statistics page.</p>
            </div>
        </div>
    );
}

export default HealthStats;
