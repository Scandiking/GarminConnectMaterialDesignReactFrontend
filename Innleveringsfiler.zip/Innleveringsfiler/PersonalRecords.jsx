import React from 'react';

function PersonalRecords() {
    return (
        <div>
            <div style={{ padding: '20px' }}>
                <h2>Personal Records</h2>
                <p>This is the personal records page.</p>
            </div>
        </div>
    );
}

export default PersonalRecords;
