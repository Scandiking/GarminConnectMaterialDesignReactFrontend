import React from 'react';

function Goals() {
    return (
        <div>
            <div style={{ padding: '20px' }}>
                <h2>Goals</h2>
                <p>This is the goals page.</p>
            </div>
        </div>
    );
}

export default Goals;
