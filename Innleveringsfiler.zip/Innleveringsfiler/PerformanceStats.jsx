import React from 'react';

function PerformanceStats() {
    return (
        <div>
            <div style={{ padding: '20px' }}>
                <h2>Performance Statistics</h2>
                <p>This is the performance page.</p>
            </div>
        </div>
    );
}

export default PerformanceStats;
