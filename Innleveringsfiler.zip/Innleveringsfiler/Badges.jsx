import React from 'react';

function Badges() {
    return (
        <div>
            <div style={{ padding: '20px' }}>
                <h2>Badges</h2>
                <p>This is the badges page.</p>
            </div>
        </div>
    );
}

export default Badges;
